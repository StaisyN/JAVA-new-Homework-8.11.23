public class Main {
    public static void main(String[] args) {


        char myChar = 71;
        char myChar2 = 169;
        int a = 89;
        byte b = 4;
        short c = 56;
        float d = 4.7333436F;
        double i = 4.355453532;
        long f = 12121L;



        System.out.println(myChar);
        System.out.println(myChar2);
        System.out.println(a);
        System.out.println(b);
        System.out.println(c);
        System.out.println(d);
        System.out.println(i);
        System.out.println(f);

        //Дано трехзначное число. Вывести на экран все цифры этого числа
        //Пример: 345
        //Вывод в консоль: Число 345 -> 3, 4, 5
        //Другой пример: 987
        //Вывод в консоль: Число 987 -> 9, 8, 7

        int number = 345;
        System.out.println("3, " +"4, " + "5");
        int number2 = 987;
        System.out.println("9, " + "8, " + "7" );

    }
}